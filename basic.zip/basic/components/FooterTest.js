import React from 'react';
import { Text, View, StyleSheet, Button, Alert, TouchableOpacity} from 'react-native';
import Constants from 'expo-constants';
import { Card } from 'react-native-paper';

import MSelect from './MSelect.js';

const FooterTest = () => {
  function skip(){

  }
  //
  return(
    <Card style={styles.card}>
        <Text style={styles.subtitle}>Selecciona que tipo de musica es tu preferida</Text>
        <MSelect placeholder="--"></MSelect>    
        <TouchableOpacity style={styles.button}>
          <Text style={styles.buttontext}>Continuar</Text>
        </TouchableOpacity>
    </Card>);
}


const styles = StyleSheet.create({
 card : {
   //display: 'flex',
   width:'100%',
   //justifyContent:'center',
   //textAlign:'center',
   //borderRadius:'0px',
 },
 subtitle:{
   display:'flex',
   paddingTop:20,
   paddingBottom:20,
   fontWeight:'bold',
   justifyContent:'center',
   textAlign:'center',
   /*
   
   */
 },
 button:{
   display: 'flex',
   marginTop: 50,
   backgroundColor:'lightgray',
   opacity:0.4,
   textAlign: 'center',
   width:'80%',
   marginLeft: 'auto',
   marginRight: 'auto',
   justifyContent:'center',
   flexDirection:'row',
   padding: 15,
   borderRadius: 50,
    /*
    
    
    
    
    
    
    
    
    
    
    */
  },
  buttontext:{
    textTransform: 'uppercase',
    /*fontWeight : "800",
    opacity: 0.4,*/
  }

});


export default FooterTest;