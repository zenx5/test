import React from 'react';
import { Text, View, StyleSheet, Button, Alert, TouchableOpacity } from 'react-native';
import Constants from 'expo-constants';
import { Card } from 'react-native-paper';
import ListBound from './ListBound';

export default _ => {
  function skip(){

  }
  //

  return(
    <Card style={styles.card}>
      <Text style={styles.title}>TEST INICIAL</Text>
      <Text style={styles.subtitle}>Selecciona que tipo de eventos te gustaria</Text>
      <ListBound></ListBound>
    </Card>);
}


const styles = StyleSheet.create({
 
  card:{
    width:'100%',
  },
  title:{
    textAlign: 'center',
    textTransform: 'uppercase',
    fontWeight:'bold',
    padding:20,
  },
  subtitle:{
    textAlign: 'center',
    marginBottom:30,
    fontWeight:'bold',
  }
});