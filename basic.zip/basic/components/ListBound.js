import React from 'react';
import { Text, View, StyleSheet, Button, Alert, TouchableOpacity } from 'react-native';
import Constants from 'expo-constants';
import { Card } from 'react-native-paper';



export default _ => {

  const list = [{
      color : '#FFFFFF',
      backgroundColor : '#E1B21C',
      title : "Discotecas"
    },{
      color : '#FFFFFF',
      backgroundColor:'#33A0F3',
      title : "Eventos Empresariales"
    },{
      color : '#F1485F',
      backgroundColor:'#F1485F0F',
      title : "Despedida de solteros"
    },{
      color : '#E1B21C',
      backgroundColor:'#E1B21C0F',
      title : "Conciertos"
    },{
      color : '#FFFFFF',
      backgroundColor:'#BE52F3',
      title : "Fiestas Privadas en Casa"
    },{
      color : '#82CC7C',
      backgroundColor:'#82CC7C0F',
      title : "Swingers"
    }];

  return(
    <Card style={styles.card}><View style={styles.boundContainer}>{list.map( item => {
      const bound = {
        backgroundColor : item.backgroundColor,
        height: 30,
        borderRadius:20,
        margin:5,
        paddingTop:5,
        paddingBottom:5,
        paddingLeft : 15,
        paddingRight : 15,
      };
      return(<TouchableOpacity style={bound} ><Text style={{color: item.color,textAlign:'center'}}>{item.title}</Text></TouchableOpacity>)})}
      </View>
  </Card>)
}

const styles = StyleSheet.create({
  card:{
    display:'flex',
  },
  boundContainer:{
    display:"flex",
    flexDirection:"row",
    flexWrap:'wrap',
    justifyContent:'center',
  }
});