import React, {useState} from 'react';
import { Text, View, StyleSheet, Button, Alert, TouchableOpacity, Modal } from 'react-native';
import Constants from 'expo-constants';
import { Card } from 'react-native-paper';
import { Ionicons } from '@expo/vector-icons';
import { useFonts, Poppins_400Regular } from '@expo-google-fonts/poppins'
import { BlurView } from 'expo-blur';


import ItemSelect from './ItemSelect';

const MSelect = props => {  
  
  const title = "Selecciona de los siguientes";

  const list = [
    {title:"Musica Pop", check:false},
    {title:"Musica Clasica", check: false},
    {title: "Jazz",check: false},
    {title:"Soul", check: false},
    {title:"Blues", check: false},
    {title:"Flamenco", check: false},
    {title:"Salsa", check: false},
    {title:"Reggaeton", check: false},
    {title:"Tango", check: false},
  ];

  const [modalVisible, setModalVisible] = useState(false);

  const open = () => setModalVisible(true);
  const close = () => setModalVisible(false);

  const modalView = {
    display : "flex",
    top:-80,
    margin: 0,
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 10,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: -200,
    },
    shadowOpacity: 0.5,
    shadowRadius: 5,
    elevation: 50,
  };

  return(
    <>
    <TouchableOpacity style={styles.select} onPress={open}>
      <Text style={styles.placeholder}>{props.placeholder}</Text>
      <Text style={styles.arrow}>></Text>
    </TouchableOpacity>
    
    <Modal 
      style={modalView}
      visible={modalVisible}
      transparent={true}
      animationType='slide'>
      <View style={styles.viewmodal}>
      <BlurView tint='dark' intensity={50} style={styles.blur}>
      <Card style={styles.cardmodal}>
        <TouchableOpacity onPress={close} style={styles.up}></TouchableOpacity>
        <Text style={styles.title}>{title}</Text>
        {list.map(elem=><ItemSelect name={elem.title} check={elem.check}></ItemSelect>)}
        </Card>
      </BlurView>
      </View>
    </Modal>
    </>
  )

}

const styles = StyleSheet.create({
  select:{
    display: 'flex',
    flexDirection:'row',
    justifyContent: 'center',
    width:'80%',
    textAlign: 'center',
    borderRadius: 50,
    padding: 5,
    borderWidth:1,
    borderColor : 'black',
    borderStyle: 'solid',
    marginLeft:'auto',
    marginRight:'auto',
  },
  placeholder:{
    fontFamily:'Poppins',
    fontWeight: 'bold',
    fontSize: 14,
    color: '#000000',
  },
  arrow:{
    position: 'absolute',
    right: 20,
    left: 'auto',
    fontFamily:'Poppins',
    fontWeight: 'bold',
    fontSize: 14,
    color: '#000000',
    /**/
  },
  viewmodal:{
    flex:1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 0,
    
  },
  blur:{
    width:'100%',
  },
  cardmodal:{
    display:'flex',
    textAlign:'center',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 100,
    width:'100%',
    flexDirection:'column',
    padding:10,
  },
  up:{
    backgroundColor:'lightgray',
    paddingTop:5,
    paddingBottom:5,
    paddingLeft:30,
    paddingRight:40,
    borderRadius: 20,
    marginBottom: 20,
    width:'30%',
    marginLeft:'auto',
    marginRight:'auto',
    /*
    
    */
  },
  title:{
    marginBottom: 10,
    fontWeight: 'bold',
    /**/
  }, 
});

export default MSelect;