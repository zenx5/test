import React, { useState } from 'react';
import {
  Text,
  View,
  StyleSheet,
  Button,
  Alert,
  TouchableOpacity,
  Modal,
} from 'react-native';
import Constants from 'expo-constants';
import { Card } from 'react-native-paper';
import { Ionicons } from '@expo/vector-icons';
import { useFonts, Poppins_400Regular } from '@expo-google-fonts/poppins';
import { FontAwesome } from '@expo/vector-icons';

const ItemSelect = (props) => {
  const [check, setCheck] = useState(false);
  const toggle = (_) => {
    setCheck(!check);
  };

  const showCheck = check ? ' !' : '';
  /**
   * 
   */
  return (
    <TouchableOpacity style={styles.item} onPress={toggle}>
      <Text style={styles.list}>{props.name}</Text>
      <FontAwesome name="check-circle" style={{display:check ? 'flex' : 'none'}} size={20} color="#33A0F3" />
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  list: {
    marginBottom: 10,
  },
  item:{
    padding:10,
    display:"flex",
    flexDirection: "row",
    justifyContent:'space-around',
    //
  }
});

export default ItemSelect;
