import * as React from 'react';
import { Text, View, StyleSheet, Image, TextInput } from 'react-native';


export default function InputBootstrap(a){
  var label = arguments[0].label || '';
  var placeholder = arguments[0].placeholder || '';
  var custom = arguments[0].custom || '';
  
  return( 
    <View style={styles.group}>
      <Text style={styles.label}>{label}</Text>
      <TextInput style={styles.control} placeholder={placeholder}></TextInput>
    </View>
  );
}

const styles = StyleSheet.create({
  group : {
    display : 'inline-block',
    color: 'red',
    paddingTop: '70px',
    paddingBottom: '70px',
    paddingLeft: '20px',
    paddingRight: '20px',
  },
  label : {
    marginRight: '10px',
  },
  control : {
   
  }
});
