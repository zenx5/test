import React from 'react';
import { Text, View, StyleSheet, Button, Alert, TouchableOpacity } from 'react-native';
import Constants from 'expo-constants';
import { Card } from 'react-native-paper';

export default _ => {
  function skip(){

  }

  /*
 
  */ 
  return( <TouchableOpacity onPress={skip} style={styles.header}>
          <Text style={styles.header_title}>B S O C I A L</Text>
          <Text style={styles.header_skip} >SKIP</Text>
        </TouchableOpacity>
    );
}


const styles = StyleSheet.create({
  card:{
    width:'100%',
    //borderRadius:'0px'
  },
  header:{
    display:"flex",
    flexDirection:"row",
    height: 80,
    paddingTop:30,
    marginBottom: 10,
    backgroundColor:'white',
    justifyContent:'center',
   /*     
    
    
    
    textTransform: 'uppercase',
    width:'100%',
    
    //borderBottomWidth:'2px',
    fontWeight:'bold',*/
  },
  header_title:{
      width: '80%',
      textAlign: 'center',
      fontWeight:"200",
      fontSize: 30,
      
  },
  header_skip:{
      width: '20%',
      textAlign: 'center',
      color: "#E1B21C",
      fontSize: 30,
      fontWeight:"700",
  }
});