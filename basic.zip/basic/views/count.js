import React from 'react';
import { Text, View, StyleSheet, Button, Alert } from 'react-native';
import Constants from 'expo-constants';
import * as ImagePicker from 'expo-image-picker';

// You can import from local files
import AssetExample from '../components/AssetExample';
import InputBootstrap from '../components/InputBootstrap';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

let openImagePickerAsync = async () => {
  let permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
  if(permissionResult.granted === false){
    alert('Permiso a la camara requerido');
    return;
  }
  
}
export default () =>{
  const [count, setCount] = React.useState(0);
  function togglin() {
    setCount(count+1);
  }
  let title = "Clicks : "+count;
  return(
    <View style={styles.container}>
      <Card>
        <InputBootstrap
          label=""
          placeholder="Codigo de Acceso"></InputBootstrap>
        <Button title={title} onPress={togglin}></Button>
        <Button title="Reset" onPress={_=>{setCount(0)}}></Button>
      </Card>
    </View>
  );

}

const styles = StyleSheet.create({
  container : {},
})
